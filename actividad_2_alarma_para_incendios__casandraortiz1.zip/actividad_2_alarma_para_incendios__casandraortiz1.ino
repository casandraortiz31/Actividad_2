
int lecturaGas = 0;
int sonidoAlarma = 13;
int luzIndicadora = 10;
int valorLimite = 600;

void setup() {
  pinMode(A0, INPUT);
  pinMode(sonidoAlarma, OUTPUT);
  pinMode(luzIndicadora, OUTPUT);
}

void loop() {
  lecturaGas = analogRead(A0);

  if (lecturaGas >= valorLimite) {
    digitalWrite(luzIndicadora, HIGH);
    tone(sonidoAlarma, 500);
  } else {
    digitalWrite(luzIndicadora, LOW);
    noTone(sonidoAlarma);
  }

  delay(100);
}
