/*var num1 = 4
var num2 = 8
let aux = num2

print("El primer numero es \(num1) y el segundo numero es \(num2)")

let temperatura = 40
if temperatura > 32 {
    print("Hace calor")
}else{
    print("Hace frio")
}

print("introduce un numero 1")
let a = Int(readLine()!)!
print("introduce el numero 2")
let b = Int(readLine()!)!
print("introduce el numero 3")
let c = Int(readLine()!)!

if a > b && a > c {
    print("El numero mayor es \(a)")
}else{
    if b > a && b > c {
        print("El numero mayor es \(b)")
    }else{
        print("El numero mayor es \(c)")
    }
}
*/

print("introduce el alto")
let alto = Int(readLine()!)!

print("introduce el ancho")
let ancho = Int(readLine()!)!

let pixeles = alto * ancho
print("el numero de pixeles es \(pixeles)")

var numero: Int
print("dime un numero:")
numero = Int(readLine()!)!

if numero % 2 == 0 {
    print("el numero es par")
} else {
    print("el numero es impar")
}