
#include <LiquidCrystal.h>

LiquidCrystal lod(12, 11, 5, 4, 3, 2);

int lecturaSensor;
int valorMapeado;
float temp;

void setup() {
  Serial.begin(9600);
  pinMode(A0, INPUT);

  lod.begin(16, 2);
  lod.print("Temperatura:");
}

void loop() {
  lecturaSensor = analogRead(A0);

  valorMapeado = map(lecturaSensor, 0, 1023, 0, 5000);
  temp = valorMapeado / 100.0;

  lod.setCursor(0, 1);
  lod.print("                ");
  lod.setCursor(0, 1);
  lod.print(temp);
  lod.print(" C");

  Serial.println(temp);
  delay(1000);
}
