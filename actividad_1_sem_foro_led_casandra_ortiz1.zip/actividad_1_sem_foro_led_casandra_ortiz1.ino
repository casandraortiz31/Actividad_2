int rojo = 13;
int amarillo = 12;
int verde = 11;

void setup() {
  pinMode(rojo, OUTPUT);
  pinMode(amarillo, OUTPUT);
  pinMode(verde, OUTPUT);
}

void loop() {

  // Primero se enciende el rojo
  digitalWrite(rojo, HIGH);
  delay(3000);
  digitalWrite(rojo, LOW);

  delay(1000);

  // Después cambia a amarillo
  digitalWrite(amarillo, HIGH);
  delay(3000);
  digitalWrite(amarillo, LOW);

  delay(1000);

  // Luego se enciende el verde
  digitalWrite(verde, HIGH);
  delay(3000);
  digitalWrite(verde, LOW);

  delay(1000);

  // Vuelve a amarillo antes de comenzar nuevamente
  digitalWrite(amarillo, HIGH);
  delay(3000);
  digitalWrite(amarillo, LOW);

  delay(1000);
}
 
  
  
  
  
  
  
  
  